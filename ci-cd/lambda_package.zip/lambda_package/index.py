import boto3
import cfnresponse
import psycopg2
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def execute_sql_file(cur, file_name):
    try:
        with open(file_name, 'r') as f:
            sql = f.read()
        cur.execute(sql)
        logger.info(f"Executed SQL file: {file_name}")
    except Exception as e:
        logger.error(f"Error executing SQL file {file_name}: {str(e)}")
        raise

def handler(event, context):
    try:
        if event['RequestType'] == 'Create':
            rds = boto3.client('rds')
            cluster_info = rds.describe_db_clusters(DBClusterIdentifier=os.environ['DB_CLUSTER_ID'])
            host = cluster_info['DBClusters'][0]['Endpoint']
            
            conn = psycopg2.connect(
                host=host,
                database='postgres',
                user=os.environ['DB_USERNAME'],
                password=os.environ['DB_PASSWORD']
            )
            
            conn.set_session(autocommit=True)
            with conn.cursor() as cur:
                execute_sql_file(cur, 'ddl.sql')
                execute_sql_file(cur, 'data.sql')
            
            conn.close()
            logger.info("Database setup completed successfully")
            cfnresponse.send(event, context, cfnresponse.SUCCESS, {})
        else:
            logger.info(f"Received {event['RequestType']} event. No action taken.")
            cfnresponse.send(event, context, cfnresponse.SUCCESS, {})
    except Exception as e:
        logger.error(f"Error in database setup: {str(e)}")
        cfnresponse.send(event, context, cfnresponse.FAILED, {})